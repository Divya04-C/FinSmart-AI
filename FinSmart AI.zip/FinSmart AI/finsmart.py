import math
import streamlit as st
import plotly.graph_objects as go
from groq import Groq
import base64
from datetime import datetime

# =====================================
# PAGE CONFIGURATION
# =====================================
st.set_page_config(
    page_title="FinSmart AI - Personal Finance Assistant",
    page_icon="💸",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for modern styling
st.markdown("""
<style>
    /* Main background */
    [data-testid="stAppViewContainer"] {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    }
    
    /* Sidebar styling */
    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, #4b6cb7 0%, #182848 100%) !important;
    }
    
    /* Sidebar text */
    [data-testid="stSidebar"] * {
        color: #ffffff !important;
    }
    
    /* Card styling */
    .finance-card {
        background: white;
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
        border-left: 4px solid #4b6cb7;
    }
    
    /* Chat messages */
    .user-message {
        background: linear-gradient(135deg, #4b6cb7 0%, #182848 100%);
        color: white;
        border-radius: 15px 15px 0 15px;
        padding: 12px;
        margin: 5px 0;
        max-width: 80%;
        margin-left: auto;
    }
    
    .bot-message {
        background: #f1f2f6;
        color: #333;
        border-radius: 15px 15px 15px 0;
        padding: 12px;
        margin: 5px 0;
        max-width: 80%;
    }
    
    /* Button styling */
    .stButton button {
        background: linear-gradient(135deg, #4b6cb7 0%, #182848 100%);
        color: white;
        border: none;
        border-radius: 8px;
        padding: 10px 20px;
        font-weight: 600;
    }
    
    .stButton button:hover {
        background: linear-gradient(135deg, #3a5998 0%, #152642 100%);
        color: white;
    }
    
    /* Header styling */
    .main-header {
        text-align: center;
        background: linear-gradient(135deg, #4b6cb7 0%, #182848 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-size: 2.8rem;
        font-weight: 800;
        margin-bottom: 0.5rem;
    }
    
    .sub-header {
        text-align: center;
        color: #5a67d8;
        font-size: 1.2rem;
        margin-bottom: 2rem;
    }
    
    /* Metric cards */
    [data-testid="stMetricValue"] {
        font-size: 1.5rem;
    }
</style>
""", unsafe_allow_html=True)

# =====================================
# Groq API Configuration
# =====================================
GROQ_API_KEY = "your api key"
GROQ_MODEL = "llama-3.1-8b-instant"

# =====================================
# Tax Calculation (Indian New Regime FY 2025-26)
# =====================================
def calculate_tax(annual_income: float) -> float:
    tax = 0
    if annual_income <= 300000:
        return 0
    elif annual_income <= 700000:
        tax = (annual_income - 300000) * 0.05
    elif annual_income <= 1000000:
        tax = (400000 * 0.05) + (annual_income - 700000) * 0.10
    elif annual_income <= 1200000:
        tax = (400000 * 0.05) + (300000 * 0.10) + (annual_income - 1000000) * 0.15
    elif annual_income <= 1500000:
        tax = (400000 * 0.05) + (300000 * 0.10) + (200000 * 0.15) + (annual_income - 1200000) * 0.20
    else:
        tax = (400000 * 0.05) + (300000 * 0.10) + (200000 * 0.15) + (300000 * 0.20) + (annual_income - 1500000) * 0.30
    return tax

# =====================================
# Groq Answer Generation
# =====================================
def generate_answer(query: str, finance_data: dict, chat_history: list = None) -> str:
    try:
        client = Groq(api_key=GROQ_API_KEY)
        context = "\n".join([f"{k}: {v}" for k, v in finance_data.items()])
        
        # Build conversation history context
        history_context = ""
        if chat_history:
            history_context = "\nPrevious conversation:\n"
            for msg in chat_history[-6:]:  # Last 6 messages for context
                role = "User" if msg["role"] == "user" else "Assistant"
                history_context += f"{role}: {msg['content']}\n"
        
        prompt = f"""
You are FinSmart AI, a helpful financial assistant specializing in Indian personal finance.

User's Financial Data:
{context}
{history_context}

Current Question: {query}

Instructions:
1. Provide clear, actionable advice based on the user's financial data
2. Keep responses concise but informative (2-4 paragraphs max)
3. Use Indian financial terminology and consider Indian tax laws
4. If data is insufficient, politely ask for more information
5. Reference previous conversation context when relevant
"""
        completion = client.chat.completions.create(
            model=GROQ_MODEL,
            messages=[
                {"role": "system", "content": "You are FinSmart AI, a helpful financial assistant specializing in Indian personal finance."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=800
        )
        return completion.choices[0].message.content
    except Exception as e:
        return f"Error generating answer: {str(e)}"

# =====================================
# Donut Chart Function
# =====================================
def Half_donut_breakdown(categories: dict, total_income: float, 
                         title: str = "Financial Breakdown", currency: str = "₹", hole: float = 0.6):
    total_income = max(0.0, float(total_income))
    labels = list(categories.keys())
    amounts = [max(0.0, float(v)) for v in categories.values()]

    if total_income == 0:
        labels = ["No data"]
        amounts = [1.0]

    percents = [(v / total_income * 100.0) if total_income > 0 else 0.0 for v in amounts]
    customdata = [[amounts[i], percents[i]] for i in range(len(amounts))]

    base_colors = [
        "#FF6B6B", "#4D96FF", "#6BCB77", "#FFD93D", "#A66DD4",
        "#FF922B", "#20C997", "#845EC2", "#2C73D2", "#008F7A"
    ]
    colors = [base_colors[i % len(base_colors)] for i in range(len(labels))]

    fig = go.Figure(go.Pie(
        labels=labels,
        values=amounts,
        hole=hole,
        direction="clockwise",
        sort=False,
        marker=dict(colors=colors),
        textinfo="label+percent",
        texttemplate="%{label}<br>%{customdata[1]:.1f}%",
        customdata=customdata,
        hovertemplate=f"%{{label}}<br>{currency}%{{customdata[0]:,.0f}}"
                      f"<br>%{{customdata[1]:.2f}}% of income<extra></extra>",
    ))

    fig.update_layout(
        title=dict(text=title, x=0.5, font=dict(size=18)),
        margin=dict(l=10, r=10, t=60, b=10),
        showlegend=False,
        height=420,
    )

    return fig

# =====================================
# STREAMLIT UI
# =====================================
def main():
    # Initialize session state for chat history
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []
    
    if "finance_data" not in st.session_state:
        st.session_state.finance_data = {}
    
    if "breakdown_data" not in st.session_state:
        st.session_state.breakdown_data = {}

    st.markdown('<h1 class="main-header">💸 FinSmart AI</h1>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Your intelligent personal finance assistant</p>', unsafe_allow_html=True)

    with st.sidebar:
        st.image("https://cdn-icons-png.flaticon.com/512/3135/3135706.png", width=80)
        st.markdown("## 🔧 Configuration")
        st.success("🚀 Powered by Groq AI")
        st.info(f"Model: {GROQ_MODEL}")
        st.divider()
        
        st.markdown("""
        ### 📋 How it works
        1. Enter your financial details
        2. Tax is calculated automatically
        3. View your financial breakdown
        4. Chat with your AI finance assistant
        5. Ask follow-up questions in natural conversation
        """)
        
        st.divider()
        st.markdown("### 💡 Tips")
        st.markdown("""
        - Ask about savings strategies
        - Get investment advice
        - Plan for tax savings
        - Discuss financial goals
        """)
        
        if st.button("🔄 Clear Chat History"):
            st.session_state.chat_history = []
            st.rerun()

    # Main content area with tabs
    tab1, tab2 = st.tabs(["📝 Financial Data", "💬 AI Assistant"])

    with tab1:
        st.markdown("### 📊 Enter Your Financial Details")
        
        col1, col2 = st.columns(2)
        
        with col1:
            monthly_income = st.number_input("💰 Monthly Income (₹)", min_value=0, step=1000, value=50000)
            rent = st.number_input("🏠 Rent / Housing (₹)", min_value=0, step=500, value=15000)
            food = st.number_input("🍔 Food / Groceries (₹)", min_value=0, step=500, value=8000)
            transport = st.number_input("🚗 Transport (₹)", min_value=0, step=500, value=3000)
        
        with col2:
            pf_percent = st.slider("📈 Provident Fund (PF) % of Income", min_value=0, max_value=100, value=12)
            investment = st.number_input("📊 Investments (₹)", min_value=0, step=500, value=5000)
            other_expenses = st.number_input("🎯 Other Expenses (₹)", min_value=0, step=500, value=4000)
        
        # Calculate button to trigger calculations
        calculate_clicked = st.button("🧮 Calculate Finances", type="primary")
        
        # Calculate financials only when button is clicked or when values change
        if calculate_clicked or monthly_income > 0:
            pf = (monthly_income * pf_percent) / 100
            annual_income = monthly_income * 12
            annual_tax = calculate_tax(annual_income)
            monthly_tax = annual_tax / 12 if annual_tax > 0 else 0
            total_expenses = rent + food + transport + pf + investment + other_expenses + monthly_tax
            savings = monthly_income - total_expenses
            
            # Store in session state
            st.session_state.finance_data = {
                "Monthly Income": f"₹{monthly_income:,}",
                "Provident Fund (PF)": f"₹{pf:,.2f} ({pf_percent}%)",
                "Income Tax (Monthly)": f"₹{monthly_tax:,.2f}",
                "Investments": f"₹{investment:,}",
                "Other Expenses": f"₹{other_expenses:,}",
                "Total Expenses": f"₹{total_expenses:,.2f}",
                "Net Savings": f"₹{savings:,.2f}",
            }

            st.session_state.breakdown_data = {
                "Rent": rent,
                "Food": food,
                "Transport": transport,
                "PF": pf,
                "Investments": investment,
                "Other Expenses": other_expenses,
                "Tax": monthly_tax,
                "Savings": savings
            }

            # Display financial metrics
            st.divider()
            st.markdown("### 📈 Financial Overview")
            
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Monthly Income", f"₹{monthly_income:,}")
            with col2:
                st.metric("Total Expenses", f"₹{total_expenses:,.2f}")
            with col3:
                st.metric("Monthly Savings", f"₹{savings:,.2f}")
            with col4:
                savings_percent = (savings / monthly_income * 100) if monthly_income > 0 else 0
                st.metric("Savings Rate", f"{savings_percent:.1f}%")
            
            # Display charts and details
            col1, col2 = st.columns([1, 1])

            with col1:
                st.markdown("#### 💰 Financial Details")
                for k, v in st.session_state.finance_data.items():
                    st.markdown(f"<div class='finance-card'><b>{k}:</b> {v}</div>", unsafe_allow_html=True)

            with col2:
                st.plotly_chart(
                    Half_donut_breakdown(st.session_state.breakdown_data, total_income=monthly_income, 
                                        title="Monthly Budget Allocation"),
                    use_container_width=True
                )
        else:
            st.info("👆 Enter your financial details and click 'Calculate Finances' to see your financial breakdown.")

    with tab2:
        st.markdown("### 💬 Chat with FinSmart AI")
        st.markdown("Ask questions about your finances, savings, investments, or anything money-related!")
        
        # Display chat history
        chat_container = st.container()
        
        with chat_container:
            for message in st.session_state.chat_history:
                if message["role"] == "user":
                    st.markdown(f"<div class='user-message'><b>You:</b> {message['content']}</div>", unsafe_allow_html=True)
                else:
                    st.markdown(f"<div class='bot-message'><b>FinSmart AI:</b> {message['content']}</div>", unsafe_allow_html=True)
        
        # Chat input
        st.divider()
        query = st.chat_input("Ask a question about your finances...", key="chat_input")
        
        if query:
            # Add user message to chat history
            st.session_state.chat_history.append({"role": "user", "content": query})
            
            # Generate and display AI response
            with st.spinner("FinSmart AI is thinking..."):
                answer = generate_answer(query, st.session_state.finance_data, st.session_state.chat_history)
                st.session_state.chat_history.append({"role": "assistant", "content": answer})
                
            # Rerun to update the chat display
            st.rerun()

if __name__ == "__main__":
    main()
    